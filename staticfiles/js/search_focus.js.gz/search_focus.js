document.addEventListener("DOMContentLoaded", function() {
    const search_field = document.getElementById("search_field");
    search_field.focus();
})